import HeroSection from "@/components/designer/HeroSection";
import SkillsSection from "@/components/designer/SkillsSection";
import ExperienceSection from "@/components/designer/ExperienceSection";
import ProjectsSection from "@/components/designer/ProjectsSection";
import EducationSection from "@/components/designer/EducationSection";

const Index = () => {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <SkillsSection />
      <ExperienceSection />
      <ProjectsSection />
      <EducationSection />
    </div>
  );
};

export default Index;
