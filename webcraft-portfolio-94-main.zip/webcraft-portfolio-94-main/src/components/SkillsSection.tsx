import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Zap, 
  Database, 
  Smartphone, 
  Code2, 
  Layers,
  Globe,
  Settings,
  Palette
} from "lucide-react";

const SkillsSection = () => {
  const skillCategories = [
    {
      icon: <Code2 className="w-6 h-6" />,
      title: "Frontend Frameworks",
      description: "Expert-level proficiency in modern JavaScript frameworks",
      skills: ["React.js", "Next.js", "TypeScript", "JavaScript", "HTML5", "CSS3"]
    },
    {
      icon: <Database className="w-6 h-6" />,
      title: "State Management",
      description: "Complex application state handling and data flow",
      skills: ["Redux", "MobX", "Recoil", "Context API", "Zustand"]
    },
    {
      icon: <Globe className="w-6 h-6" />,
      title: "API Integration",
      description: "Seamless backend integration and data management",
      skills: ["RESTful APIs", "GraphQL", "Axios", "Fetch API", "WebSockets"]
    },
    {
      icon: <Smartphone className="w-6 h-6" />,
      title: "Responsive Design",
      description: "Cross-device compatibility and mobile-first approach",
      skills: ["Mobile-First", "Flexbox", "Grid", "Media Queries", "PWA"]
    },
    {
      icon: <Palette className="w-6 h-6" />,
      title: "Styling & UI",
      description: "Modern styling solutions and component libraries",
      skills: ["Tailwind CSS", "Styled Components", "SASS", "CSS Modules", "Material-UI"]
    },
    {
      icon: <Settings className="w-6 h-6" />,
      title: "Development Tools",
      description: "Professional development and deployment workflow",
      skills: ["Git", "Webpack", "Vite", "ESLint", "Prettier", "Jest"]
    }
  ];

  return (
    <section className="py-20 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">
            <Zap className="w-4 h-4 mr-2" />
            Technical Expertise
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Skills & Technologies
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Deep expertise in modern frontend technologies with a focus on scalable, 
            performant applications and exceptional user experiences.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category, index) => (
            <Card key={index} className="tech-card group">
              <CardHeader>
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
                    {category.icon}
                  </div>
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {category.description}
                </p>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, skillIndex) => (
                    <Badge 
                      key={skillIndex} 
                      variant="secondary" 
                      className="skill-badge text-xs"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-4 p-6 bg-card/50 backdrop-blur-sm rounded-2xl border border-border/50">
            <Layers className="w-8 h-8 text-primary" />
            <div className="text-left">
              <h3 className="font-semibold text-lg">E-commerce Specialist</h3>
              <p className="text-muted-foreground">
                Advanced experience in large-scale e-commerce projects with complex business logic
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;