import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, Building2, TrendingUp } from "lucide-react";

const ExperienceSection = () => {
  const experiences = [
    {
      title: "UI/UX Designer & Front-End Developer",
      company: "Gopele",
      location: "Remote",
      period: "Jan 2025 – Present",
      type: "Remote Volunteership",
      highlights: [
        "Designing multi-user educational platform following user-centered design principles",
        "Created wireframes, mock-ups, and interactive prototypes for complex user flows",
        "Developed responsive and performant user experiences using HTML, CSS, and JavaScript",
        "Defined and maintained component libraries for UI consistency",
        "Applied WCAG 2.1 accessibility standards to all UI elements",
        "Incorporated gamification features: rewards, badges, leaderboard, and progress tracking"
      ]
    },
    {
      title: "Front-End Developer Intern",
      company: "The Water Council",
      location: "Milwaukee, WI",
      period: "Sept 2024 – Dec 2024",
      type: "Internship",
      highlights: [
        "Translated Figma/Adobe mockups into responsive websites using Angular, HTML5, CSS3",
        "Designed wireframes and interactive prototypes to optimize user flow",
        "Conducted UX research and A/B testing, improving engagement by 18%",
        "Implemented WCAG accessibility fixes, improving compliance scores by 20%",
        "Applied StoryBrand-style copywriting for clear user messaging"
      ]
    },
    {
      title: "Associate Front-End Developer",
      company: "Chirpn IT Solutions",
      location: "India",
      period: "March 2020 - January 2023",
      type: "Full-time",
      highlights: [
        "Designed end-to-end UI/UX workflows including wireframes, prototypes, and mockups",
        "Built mobile-first, responsive, and performant websites with modern technologies",
        "Maintained UI design systems and reusable components across 5+ client products",
        "Conducted heuristic evaluations and QA, reducing UI bugs by 30%",
        "Collaborated with cross-functional teams to refine complex workflows"
      ]
    },
    {
      title: "IT Trainee",
      company: "EC Mobility",
      location: "India",
      period: "April 2018 - July 2018",
      type: "Trainee",
      highlights: [
        "Developed mobile-friendly UI layouts for internal tools, improving usability by 15%",
        "Translated design mockups into responsive web pages",
        "Documented design workflows to improve knowledge sharing across teams"
      ]
    }
  ];

  return (
    <section className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Work Experience
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            5+ years of experience creating user-centered designs and developing responsive web applications
          </p>
        </div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <Card key={index} className="design-card">
              <CardHeader>
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div className="space-y-2">
                    <CardTitle className="text-xl lg:text-2xl text-primary">
                      {exp.title}
                    </CardTitle>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Building2 className="w-4 h-4" />
                      <span className="font-medium">{exp.company}</span>
                    </div>
                  </div>
                  <div className="flex flex-col lg:items-end gap-2">
                    <Badge variant="outline" className="w-fit">
                      {exp.type}
                    </Badge>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{exp.period}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{exp.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {exp.highlights.map((highlight, highlightIndex) => (
                    <div key={highlightIndex} className="flex items-start gap-3">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground leading-relaxed">{highlight}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Achievement Stats */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="design-card text-center space-y-3">
            <TrendingUp className="w-8 h-8 text-primary mx-auto" />
            <h3 className="text-2xl font-bold text-primary">18%</h3>
            <p className="text-sm text-muted-foreground">Engagement Improvement</p>
          </div>
          <div className="design-card text-center space-y-3">
            <TrendingUp className="w-8 h-8 text-primary mx-auto" />
            <h3 className="text-2xl font-bold text-primary">20%</h3>
            <p className="text-sm text-muted-foreground">Accessibility Compliance</p>
          </div>
          <div className="design-card text-center space-y-3">
            <TrendingUp className="w-8 h-8 text-primary mx-auto" />
            <h3 className="text-2xl font-bold text-primary">30%</h3>
            <p className="text-sm text-muted-foreground">UI Bug Reduction</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;