import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Figma, Users, Smartphone, Utensils, GraduationCap } from "lucide-react";

const ProjectsSection = () => {
  const projects = [
    {
      title: "GreenThumb – EcoGarden Website",
      description: "Responsive web platform focused on sustainable gardening and environmental awareness",
      icon: <GraduationCap className="w-8 h-8" />,
      type: "Web Platform",
      role: "UI/UX Designer",
      figmaUrl: "https://www.figma.com/proto/1mZlnHALZznxEM79NNXeAM/Major-Design?node-id=130-775&p=f&t=Xh8Z95HXtvE8dU5Z-0&scaling=min-zoom&content-scaling=fixed&page-id=130%3A774",
      highlights: [
        "Designed wireframes, mockups, and interactive prototypes",
        "Applied user-centered design principles for intuitive navigation",
        "Implemented responsive layouts optimized for all devices",
        "Created reusable component libraries for design consistency",
        "Conducted usability testing with target users",
        "Integrated StoryBrand-style copywriting"
      ],
      tags: ["Figma", "Responsive Design", "Usability Testing", "Component Library"]
    },
    {
      title: "Networkly – Social Corporate Mobile App",
      description: "Professional networking platform designed to enhance corporate collaboration and productivity",
      icon: <Users className="w-8 h-8" />,
      type: "Mobile App",
      role: "UX/UI Designer",
      figmaUrl: "https://www.figma.com/proto/FCsK4XVxp7DUa0bHVTSSZ9/networkly?node-id=59-430&p=f&t=2i2UHytlzFf2Goy3-0&scaling=scale-down&content-scaling=fixed&page-id=56%3A338&starting-point-node-id=59%3A430&show-proto-sidebar=1",
      highlights: [
        "Designed 20+ high-fidelity screens including onboarding, chat, calendar, profiles",
        "Built interactive prototypes simulating real user interactions",
        "Developed learner-focused dashboards and social engagement flows",
        "Applied WCAG 2.1 accessibility standards across all screens",
        "Designed visual hierarchy and information architecture",
        "Collaborated with developers for smooth implementation"
      ],
      tags: ["Mobile Design", "Interactive Prototypes", "Accessibility", "Social Features"]
    },
    {
      title: "ChickChirp – Food Ordering Mobile App",
      description: "Comprehensive food delivery application with gamification and real-time order tracking",
      icon: <Utensils className="w-8 h-8" />,
      type: "Mobile App",
      role: "UX/UI Designer",
      figmaUrl: "https://www.figma.com/proto/sOijRxQBCCob5YwCYsslmc/ChickChirp?node-id=45-165&p=f&t=3ycAJ401TxPXtCpi-1&scaling=scale-down&content-scaling=fixed&page-id=0%3A1&starting-point-node-id=37%3A136",
      highlights: [
        "Created 30+ interactive screens covering complete user journey",
        "Designed gamified interactions: badges, progress tracking, and rewards",
        "Built responsive mobile-first layouts with light and dark themes",
        "Conducted A/B testing to improve checkout flow and reduce drop-off",
        "Defined component libraries for reusable UI elements",
        "Integrated APIs for real-time updates and dynamic content"
      ],
      tags: ["Food Delivery", "Gamification", "A/B Testing", "Dark Mode"]
    },
    {
      title: "Gopele – Multi-User Education Platform",
      description: "Comprehensive educational platform serving Learners, Teachers, and Parents with AI-driven recommendations",
      icon: <GraduationCap className="w-8 h-8" />,
      type: "Web Platform",
      role: "UI/UX Designer & Frontend Developer",
      highlights: [
        "Designed comprehensive user flows for multi-user roles with AI recommendations",
        "Developed wireframes, mockups, and prototypes for complex workflows",
        "Built responsive UI components using HTML, CSS, and JavaScript",
        "Applied WCAG 2.1 accessibility standards for inclusive design",
        "Implemented gamification: badges, leaderboards, progress tracking",
        "Maintained component libraries for consistency and faster delivery"
      ],
      tags: ["Education", "Multi-user", "AI Integration", "Gamification", "Frontend Development"]
    }
  ];

  return (
    <section className="py-20 px-6 bg-muted/20">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Featured Projects
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A showcase of user-centered design solutions created with Figma, featuring interactive prototypes and comprehensive user experiences
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card key={index} className="design-card group">
              <CardHeader className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                    {project.icon}
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs">
                      {project.type}
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {project.role}
                    </Badge>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">
                    {project.title}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {project.description}
                  </p>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Figma Preview */}
                {project.figmaUrl && (
                  <div className="figma-frame project-preview" onClick={() => window.open(project.figmaUrl, '_blank')}>
                    <iframe
                      src={project.figmaUrl}
                      className="w-full h-64 rounded-xl"
                      title={`${project.title} Figma Prototype`}
                      allowFullScreen
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-4">
                      <Button size="sm" className="creative-glow">
                        <Figma className="w-4 h-4 mr-2" />
                        View Prototype
                      </Button>
                    </div>
                  </div>
                )}

                {/* Highlights */}
                <div className="space-y-3">
                  {project.highlights.slice(0, 4).map((highlight, highlightIndex) => (
                    <div key={highlightIndex} className="flex items-start gap-3">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{highlight}</p>
                    </div>
                  ))}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span key={tagIndex} className="skill-tag text-xs">
                      {tag}
                    </span>
                  ))}
                </div>

                {/* CTA */}
                {project.figmaUrl && (
                  <Button 
                    variant="outline" 
                    className="w-full group-hover:border-primary/40 transition-colors"
                    onClick={() => window.open(project.figmaUrl, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Interactive Prototype
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Project Stats */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="design-card text-center space-y-3">
            <h3 className="text-3xl font-bold text-primary">70+</h3>
            <p className="text-sm text-muted-foreground">Interactive Screens Designed</p>
          </div>
          <div className="design-card text-center space-y-3">
            <h3 className="text-3xl font-bold text-primary">4</h3>
            <p className="text-sm text-muted-foreground">Major Projects Completed</p>
          </div>
          <div className="design-card text-center space-y-3">
            <h3 className="text-3xl font-bold text-primary">100%</h3>
            <p className="text-sm text-muted-foreground">WCAG 2.1 Compliance</p>
          </div>
          <div className="design-card text-center space-y-3">
            <h3 className="text-3xl font-bold text-primary">5+</h3>
            <p className="text-sm text-muted-foreground">Component Libraries Built</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;