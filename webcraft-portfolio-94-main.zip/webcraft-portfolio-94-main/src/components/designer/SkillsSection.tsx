import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Figma, Palette, Code, BarChart3, Users, Zap } from "lucide-react";

const SkillsSection = () => {
  const skillCategories = [
    {
      icon: <Figma className="w-8 h-8" />,
      title: "UI/UX & Design",
      description: "User-centered design with modern tools",
      skills: [
        "UI & UX Design", "Wireframes & Mockups", "Interactive Prototypes", 
        "Visual Design", "User Flow", "Information Architecture", 
        "Usability Best Practices", "Figma Design Systems", "Adobe CC", 
        "Accessibility (WCAG 2.1)", "Responsive Design"
      ]
    },
    {
      icon: <Code className="w-8 h-8" />,
      title: "Frontend Development",
      description: "Modern web technologies and frameworks",
      skills: [
        "HTML5", "CSS3", "JavaScript (ES6+)", "React", "Vue.js", 
        "Angular", "TypeScript", "Bootstrap", "LESS", "Mobile-First Design"
      ]
    },
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: "Data Visualization & APIs",
      description: "Interactive data and backend integration",
      skills: [
        "D3.js", "Chart.js", "RESTful APIs", "Real-time Integration", 
        "Data Visualization", "Performance Optimization"
      ]
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Collaboration & Tools",
      description: "Cross-functional teamwork and project management",
      skills: [
        "Cross-functional Teams", "Agile Methodology", "Git & GitHub", 
        "JIRA", "UX Research", "A/B Testing", "StoryBrand Copywriting"
      ]
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Performance & Optimization",
      description: "User experience optimization and analytics",
      skills: [
        "Responsive Experiences", "Page Speed Optimization", "SEO", 
        "Google Analytics", "Usability Testing", "User Research"
      ]
    }
  ];

  return (
    <section className="py-20 px-6 bg-muted/20">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Technical Skills
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive expertise in UI/UX design, frontend development, and user experience optimization
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <Card key={index} className="design-card group">
              <CardHeader className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                  {category.icon}
                </div>
                <div className="space-y-2">
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                  <p className="text-sm text-muted-foreground">{category.description}</p>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, skillIndex) => (
                    <span key={skillIndex} className="skill-tag">
                      {skill}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Design Philosophy */}
        <div className="mt-16 text-center space-y-6">
          <div className="design-card max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-4 mb-6">
              <Palette className="w-8 h-8 text-primary" />
              <h3 className="text-2xl font-bold">Design Philosophy</h3>
            </div>
            <p className="text-lg text-muted-foreground leading-relaxed">
              I believe in creating inclusive, accessible, and user-centered designs that solve real problems. 
              My approach combines data-driven insights with creative innovation to deliver experiences that 
              delight users while achieving business objectives. Every pixel serves a purpose, and every 
              interaction tells a story.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;