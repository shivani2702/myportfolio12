import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Phone, Mail, ExternalLink, Figma, Palette } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="hero-designer min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-6xl mx-auto text-center space-y-12">
        {/* Profile Header */}
        <div className="space-y-6">
          <div className="relative inline-block">
            <div className="w-32 h-32 mx-auto bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center shadow-[var(--shadow-glow)]">
              <Palette className="w-16 h-16 text-primary-foreground" />
            </div>
            <div className="absolute -bottom-2 -right-2 bg-primary text-primary-foreground rounded-full p-2 shadow-lg">
              <Figma className="w-5 h-5" />
            </div>
          </div>
          
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              Shivani Gupta
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground font-medium">
              UI/UX Designer & Frontend Developer
            </p>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Creating intuitive digital experiences through user-centered design, accessibility, and modern frontend technologies. 
              Specializing in Figma prototyping, design systems, and responsive web development.
            </p>
          </div>
        </div>

        {/* Contact Info */}
        <div className="flex flex-wrap justify-center gap-6 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span>Kalamazoo, MI</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Phone className="w-4 h-4" />
            <span>269-779-0259</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Mail className="w-4 h-4" />
            <span>guptashivani271997@gmail.com</span>
          </div>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button size="lg" className="creative-glow group">
            <ExternalLink className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
            View Portfolio
          </Button>
          <Button variant="secondary" size="lg" className="group">
            <ExternalLink className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
            LinkedIn Profile
          </Button>
        </div>

        {/* Education Quick Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <div className="design-card text-center space-y-3">
            <h3 className="text-lg font-semibold text-primary">Current Education</h3>
            <p className="text-sm text-muted-foreground">MS in Computer Science</p>
            <p className="text-sm font-medium">University of Wisconsin-Milwaukee</p>
            <Badge variant="outline" className="text-xs">Graduating May 2025</Badge>
          </div>
          <div className="design-card text-center space-y-3">
            <h3 className="text-lg font-semibold text-primary">Experience</h3>
            <p className="text-sm text-muted-foreground">5+ Years in UI/UX Design</p>
            <p className="text-sm font-medium">Frontend Development & Prototyping</p>
            <Badge variant="outline" className="text-xs">Remote & Onsite</Badge>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;