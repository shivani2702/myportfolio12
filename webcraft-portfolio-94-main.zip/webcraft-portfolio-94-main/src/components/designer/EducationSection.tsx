import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, MapPin, Calendar, Award } from "lucide-react";

const EducationSection = () => {
  const education = [
    {
      degree: "MS in Computer Science",
      school: "University of Wisconsin-Milwaukee",
      location: "Milwaukee, WI",
      period: "Graduation: May 2025",
      gpa: "3.3/4.0",
      status: "current",
      highlights: [
        "Focus on Human-Computer Interaction and User Experience Design",
        "Advanced coursework in Data Visualization and Web Technologies",
        "Research in Accessibility and Inclusive Design Practices",
        "Leadership in design-focused student organizations"
      ]
    },
    {
      degree: "Bachelor of Engineering in Computer Science",
      school: "DIEMS Aurangabad",
      location: "India",
      period: "Graduated: May 2019",
      gpa: "7.84/10.00",
      status: "completed",
      highlights: [
        "Strong foundation in Computer Science fundamentals",
        "Projects focused on web development and user interface design",
        "Active participation in design and technology clubs",
        "Academic excellence in software engineering coursework"
      ]
    }
  ];

  return (
    <section className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Education
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Academic foundation in Computer Science with specialization in user experience and interface design
          </p>
        </div>

        <div className="space-y-8">
          {education.map((edu, index) => (
            <Card key={index} className="design-card">
              <CardHeader>
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center text-primary flex-shrink-0">
                      <GraduationCap className="w-8 h-8" />
                    </div>
                    <div className="space-y-2">
                      <CardTitle className="text-xl lg:text-2xl text-primary">
                        {edu.degree}
                      </CardTitle>
                      <p className="text-lg font-medium text-foreground">
                        {edu.school}
                      </p>
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{edu.location}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>{edu.period}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-start lg:items-end gap-2">
                    <Badge 
                      variant={edu.status === 'current' ? 'default' : 'secondary'}
                      className="w-fit"
                    >
                      {edu.status === 'current' ? 'In Progress' : 'Completed'}
                    </Badge>
                    <div className="flex items-center gap-2 text-sm">
                      <Award className="w-4 h-4 text-primary" />
                      <span className="font-medium">CGPA: {edu.gpa}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {edu.highlights.map((highlight, highlightIndex) => (
                    <div key={highlightIndex} className="flex items-start gap-3">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground leading-relaxed">{highlight}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Academic Achievements */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="design-card text-center space-y-4">
            <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl flex items-center justify-center text-primary mx-auto">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold">Academic Excellence</h3>
            <p className="text-sm text-muted-foreground">
              Consistent academic performance with focus on human-computer interaction and design principles
            </p>
          </div>
          <div className="design-card text-center space-y-4">
            <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl flex items-center justify-center text-primary mx-auto">
              <GraduationCap className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold">Continuous Learning</h3>
            <p className="text-sm text-muted-foreground">
              Pursuing advanced degree while gaining practical experience in UI/UX design and development
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSection;