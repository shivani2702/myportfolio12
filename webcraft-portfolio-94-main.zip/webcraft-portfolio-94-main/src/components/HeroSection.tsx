import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Code, Rocket } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="hero-section min-h-screen flex items-center justify-center relative">
      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          <Badge variant="secondary" className="mb-8 text-sm font-medium">
            <Code className="w-4 h-4 mr-2" />
            Senior Frontend Developer
          </Badge>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-primary via-accent to-primary-glow bg-clip-text text-transparent">
              Expert Frontend
            </span>
            <br />
            <span className="text-foreground">Developer</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
            4+ years of professional experience crafting exceptional web and mobile experiences 
            with <span className="text-primary font-semibold">React</span>, <span className="text-accent font-semibold">Next.js</span>, 
            and <span className="text-primary-glow font-semibold">TypeScript</span>
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" className="professional-glow group">
              View My Work
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="outline" size="lg" className="backdrop-blur-sm">
              <Rocket className="w-5 h-5 mr-2" />
              Let's Connect
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-4">
              <div className="text-3xl font-bold text-primary mb-2">4+</div>
              <div className="text-sm text-muted-foreground">Years Experience</div>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold text-accent mb-2">50+</div>
              <div className="text-sm text-muted-foreground">Projects Completed</div>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold text-primary-glow mb-2">10+</div>
              <div className="text-sm text-muted-foreground">Technologies</div>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold text-success mb-2">100%</div>
              <div className="text-sm text-muted-foreground">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;