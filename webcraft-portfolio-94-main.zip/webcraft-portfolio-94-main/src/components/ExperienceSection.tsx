import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Briefcase, Calendar, TrendingUp, Award } from "lucide-react";

const ExperienceSection = () => {
  const highlights = [
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "4+ Years Professional Experience",
      description: "Non-internship professional frontend development across multiple industries"
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Expert-Level React Proficiency",
      description: "Deep understanding of React ecosystem, hooks, patterns, and best practices"
    },
    {
      icon: <Briefcase className="w-6 h-6" />,
      title: "Large-Scale E-commerce Projects",
      description: "Successfully delivered complex e-commerce solutions with advanced TypeScript"
    }
  ];

  return (
    <section className="py-20 px-6 bg-card/20">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">
            <Calendar className="w-4 h-4 mr-2" />
            Professional Journey
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
              Experience & Expertise
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            A proven track record of delivering high-quality frontend solutions 
            with cutting-edge technologies and industry best practices.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {highlights.map((highlight, index) => (
            <Card key={index} className="tech-card text-center">
              <CardHeader>
                <div className="mx-auto p-3 rounded-xl bg-primary/10 text-primary w-fit mb-4">
                  {highlight.icon}
                </div>
                <CardTitle className="text-xl mb-3">{highlight.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {highlight.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="max-w-4xl mx-auto">
          <Card className="tech-card">
            <CardHeader>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-success/10 text-success">
                  <Briefcase className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="text-2xl">Senior Frontend Developer</CardTitle>
                  <p className="text-muted-foreground">Professional Development Focus</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-lg mb-3 text-primary">Core Responsibilities</h4>
                  <ul className="space-y-2 text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      Building scalable React applications with TypeScript
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      Implementing complex state management solutions
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      Ensuring responsive design across all devices
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      Integrating with RESTful and GraphQL APIs
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-3 text-accent">Key Achievements</h4>
                  <ul className="space-y-2 text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                      Delivered 50+ successful projects
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                      Specialized in e-commerce platforms
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                      Expert in modern development workflows
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                      Consistent cross-device user experiences
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;